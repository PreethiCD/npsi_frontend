var app = angular.module("myApp", []);

app.controller('MainCtrl', ['$scope','$filter','$http', function ($scope, $filter, $http){


	$scope.logged_in_user = localStorage.getItem('npsevents_UserName');

	var selectedEventID = localStorage.getItem('selectedEventID', 0);
	var get_url = "http://npsevents.pythonanywhere.com/register/list_by_event/"+selectedEventID+"?format=json";

	$http.get(get_url).then( function(response) 
	{
			   $scope.students = response.data;
	});
	

  
  $scope.errorMessage = false;
  
  $scope.addRow = function () {
	  
	  


  }
  
  $scope.remove = function () {


  }
  
  $scope.checkAll = function () {
    $scope.selectedAll = false;
    if(!$scope.selectedAll) { 
      $scope.selectedAll = true;
    } else { 
      $scope.selectedAll = false;
    }
    angular.forEach($scope.students, function(student){
      student.selected = $scope.selectedAll;
    });
  }
  $scope.singleStudentSelected = false;
  
  $scope.setSelectedStudent = function (student){
    if($scope.students.filter(x => x.selected).length > 1){
      $scope.selectedStudent = null;
      $scope.singleStudentSelected = false;
    } else {
      $scope.selectedStudent = angular.copy($scope.students.find(x => x.selected));
      $scope.singleStudentSelected = !!$scope.selectedStudent;
    }
  }
  
  $scope.edit = function() {
    if(!!$scope.students.find(x => x.studentName === $scope.selectedStudent.student.studentName && x.studentEmail === $scope.selectedStudent.student.studentEmail 
				&& x.score === $scope.selectedStudent.score && x.Grade === $scope.selectedStudent.student.Grade)) {
      //alert('already eixsts');
      $scope.errorMessage = true;
      return;
    }
		var RegistrationJSON = { "event": "", "student": "" , "score": ""};	
		var Student_Modify_url = "http://npsevents.pythonanywhere.com/register/"+$scope.selectedStudent.id;

		RegistrationJSON.event = selectedEventID;
		RegistrationJSON.student = $scope.selectedStudent.student.id;
		RegistrationJSON.score = $scope.selectedStudent.score;
		$http.put(Student_Modify_url,RegistrationJSON).success(function(response) 
		{
			if(response.err){
			  console.log('Error: ' + response.err);
			  newDataList.push(selected);

			} else {
				console.log('Saved '+response);
				var studentToEdit = $scope.students.find(x => x.id === $scope.selectedStudent.id);
				studentToEdit.score = $scope.selectedStudent.score;			  

			}
	
		});

	  }
	  


}]);


