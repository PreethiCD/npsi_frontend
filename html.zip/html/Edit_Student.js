var app = angular.module("myApp", []);

app.controller('MainCtrl', ['$scope','$filter','$http', function ($scope, $filter, $http){

	$scope.logged_in_user = localStorage.getItem('npsevents_UserName');

	var get_url = "http://npsevents.pythonanywhere.com/student/allStudents/?format=json";

	$http.get(get_url).then( function(response) 
	{
			   $scope.students = response.data;
	});
	

  
  $scope.errorMessage = false;
  
  $scope.addRow = function () {
	  
	  
		var StudentJSON = { "studentName": "", "studentEmail": "" , "Age": "", "Grade": ""};	
		var Student_add_url = "http://npsevents.pythonanywhere.com/student/addStudent/";

		StudentJSON.studentName = $scope.selectedStudent.studentName;
		StudentJSON.studentEmail = $scope.selectedStudent.studentEmail;
		StudentJSON.Age = $scope.selectedStudent.Age;
		StudentJSON.Grade = $scope.selectedStudent.Grade;
		
		$http.post(Student_add_url, StudentJSON).success(function(response) 
		{
			if(response.err){
			  console.log('Error: ' + response.err);
			  
			} else {
			  console.log('Saved '+response);
				$scope.students.push({'studentName': $scope.selectedStudent.studentName, 'studentEmail': $scope.selectedStudent.studentEmail, 'Age': $scope.selectedStudent.Age, 'Grade': $scope.selectedStudent.Grade});
				$scope.selectedStudent.studentName = '';
				$scope.selectedStudent.studentEmail = '';
				$scope.selectedStudent.Age = '';	
				$scope.selectedStudent.Grade = '';			
							  
			}

		});
					  
					  


  }
  
  $scope.remove = function () {
    var newDataList = [];
    $scope.selectedAll = false;
    angular.forEach($scope.students, function(selected) {
      if(!selected.selected) {
        newDataList.push(selected);
      } else {
			var Student_delete_url = "http://npsevents.pythonanywhere.com/student/"+selected.id;

		
			$http.delete(Student_delete_url).success(function(response) 
			{
				if(response.err){
				  console.log('Error: ' + response.err);
				  newDataList.push(selected);

				} else {
				  console.log('Saved '+response);
				}
		
			});


	  }
	  
      $scope.students = newDataList;
      $scope.selectedStudent.studentName = '';
      $scope.selectedStudent.studentEmail = '';
      $scope.selectedStudent.Age = '';
      $scope.selectedStudent.Grade = '';
	  
    });

  }
  
  $scope.checkAll = function () {
    $scope.selectedAll = false;
    if(!$scope.selectedAll) { 
      $scope.selectedAll = true;
    } else { 
      $scope.selectedAll = false;
    }
    angular.forEach($scope.students, function(student){
      student.selected = $scope.selectedAll;
    });
  }
  $scope.singleStudentSelected = false;
  
  $scope.setSelectedStudent = function (student){
    if($scope.students.filter(x => x.selected).length > 1){
      $scope.selectedStudent = null;
      $scope.singleStudentSelected = false;
    } else {
      $scope.selectedStudent = angular.copy($scope.students.find(x => x.selected));
      $scope.singleStudentSelected = !!$scope.selectedStudent;
    }
  }
  
  $scope.edit = function() {
    if(!!$scope.students.find(x => x.studentName === $scope.selectedStudent.studentName && x.studentEmail === $scope.selectedStudent.studentEmail 
				&& x.Age === $scope.selectedStudent.Age && x.Grade === $scope.selectedStudent.Grade)) {
      //alert('already eixsts');
      $scope.errorMessage = true;
      return;
    }
		var StudentJSON = { "studentName": "", "studentEmail": "" , "Age": "", "Grade": ""};	
		var Student_Modify_url = "http://npsevents.pythonanywhere.com/student/"+$scope.selectedStudent.id;

		StudentJSON.studentName = $scope.selectedStudent.studentName;
		StudentJSON.studentEmail = $scope.selectedStudent.studentEmail;
		StudentJSON.Age = $scope.selectedStudent.Age;
		StudentJSON.Grade = $scope.selectedStudent.Grade;
		$http.put(Student_Modify_url,StudentJSON).success(function(response) 
		{
			if(response.err){
			  console.log('Error: ' + response.err);
			  newDataList.push(selected);

			} else {
				console.log('Saved '+response);
				var studentToEdit = $scope.students.find(x => x.id === $scope.selectedStudent.id);
				studentToEdit.studentName = $scope.selectedStudent.studentName;
				studentToEdit.studentEmail = $scope.selectedStudent.studentEmail;
				studentToEdit.Age = $scope.selectedStudent.Age;	
				studentToEdit.Grade = $scope.selectedStudent.Grade;			  

			}
	
		});

	  }

}]);