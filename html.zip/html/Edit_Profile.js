var app = angular.module("myApp", []);

app.controller('MainCtrl', ['$scope','$filter','$http', function ($scope, $filter, $http){


	$scope.logged_in_user = localStorage.getItem('npsevents_UserName');

	var selectedEventID = localStorage.getItem('npsevents_selectedEventID', 0);
	var studentID = localStorage.getItem('npsevents_userId', 0);
	
	var get_url = "http://npsevents.pythonanywhere.com/student/"+studentID+"?format=json";

	$http.get(get_url).then( function(response) 
	{
			   $scope.loggedInStudent = response.data;
	});
	

  
	$scope.errorMessage = false;

  
	$scope.checkAll = function () {
	$scope.selectedAll = false;
	if(!$scope.selectedAll) { 
	  $scope.selectedAll = true;
	} else { 
	  $scope.selectedAll = false;
	}
	angular.forEach($scope.loggedInStudent, function(student){
	  student.selected = $scope.selectedAll;
	});
	}
	$scope.singleStudentSelected = false;
  
	$scope.setSelectedStudent = function (student){
	if($scope.loggedInStudent.filter(x => x.selected).length > 1){
	  $scope.selectedStudent = null;
	  $scope.singleStudentSelected = false;
	} else {
	  $scope.selectedStudent = angular.copy($scope.loggedInStudent.find(x => x.selected));
	  $scope.singleStudentSelected = !!$scope.selectedStudent;
	}
	}
  
  $scope.edit = function() {
			var StudentJSON = { "studentName": "", "studentEmail": "" , "Age": "", "Grade": "","password":""};	
			var Student_Modify_url = "http://npsevents.pythonanywhere.com/student/"+$scope.loggedInStudent.id;

			StudentJSON.studentName = $scope.loggedInStudent.studentName;
			StudentJSON.studentEmail = $scope.loggedInStudent.studentEmail;
			StudentJSON.Age = $scope.loggedInStudent.Age;
			StudentJSON.Grade = $scope.loggedInStudent.Grade;
			StudentJSON.password = $scope.loggedInStudent.password;
			
			$http.put(Student_Modify_url,StudentJSON).then( function mySuccess(response) 
			{
				console.log('Saved '+response);
				

			}, function myError(response) {
			
					//Path of failure response
					//Display the failure status
				    onsole.log("Error - Http Status "+response.status);
            });

	  }
	  


}]);


