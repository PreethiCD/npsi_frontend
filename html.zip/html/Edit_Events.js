var app = angular.module("myApp", []);

app.controller('MainCtrl', ['$scope','$filter','$http', function ($scope, $filter, $http){

	$scope.logged_in_user = localStorage.getItem('npsevents_UserName');

	var get_url = "http://npsevents.pythonanywhere.com/event/allEvents/?format=json";

	$http.get(get_url).then( function(response) 
	{
			   $scope.events = response.data;
	});
	

  
	$scope.errorMessage = false;
  
	$scope.addRow = function () {
	  
	  
		var StudentJSON = { "eventName": "", "eventDescription": "" , "eventOwner": "", "eventStartDate": "", "eventEndDate": "","eventDifficulty": ""};	
		var Student_add_url = "http://npsevents.pythonanywhere.com/event/addEvent/";

		StudentJSON.eventName = $scope.selectedEvent.eventName;
		StudentJSON.eventDescription = $scope.selectedEvent.eventDescription;
		StudentJSON.eventOwner = $scope.selectedEvent.eventOwner;
		StudentJSON.eventStartDate = $scope.selectedEvent.eventStartDate;
		StudentJSON.eventEndDate = $scope.selectedEvent.eventEndDate;
		
		
		StudentJSON.eventDifficulty = $scope.selectedEvent.eventDifficulty;
		
		$http.post(Student_add_url, StudentJSON).success(function(response) 
		{
			if(response.err){
			  console.log('Error: ' + response.err);
			  
			} else {
			  console.log('Saved '+response);
				$scope.events.push({'eventName': $scope.selectedEvent.eventName, 'eventDescription': $scope.selectedEvent.eventDescription, 'eventOwner': $scope.selectedEvent.eventOwner, 'eventStartDate': $scope.selectedEvent.eventStartDate,'eventEndDate': $scope.selectedEvent.eventEndDate,'eventDifficulty': $scope.selectedEvent.eventDifficulty});
				$scope.selectedEvent.eventName = '';
				$scope.selectedEvent.eventDescription = '';
				$scope.selectedEvent.eventOwner = '';	
				$scope.selectedEvent.eventStartDate = '';	
				$scope.selectedEvent.eventEndDate = '';	
				$scope.selectedEvent.eventDifficulty = '';			
							  
			}

		});
					  
					  


  }
  
  $scope.remove = function () {
    var newDataList = [];
    $scope.selectedAll = false;
    angular.forEach($scope.events, function(selected) {
      if(!selected.selected) {
        newDataList.push(selected);
      } else {
			var Student_delete_url = "http://npsevents.pythonanywhere.com/event/"+selected.id;

		
			$http.delete(Student_delete_url).success(function(response) 
			{
				if(response.err){
				  console.log('Error: ' + response.err);
				  newDataList.push(selected);

				} else {
				  console.log('Saved '+response);
				}
		
			});


	  }
	  
      $scope.events = newDataList;
      $scope.selectedEvent.eventName = '';
      $scope.selectedEvent.eventDescription = '';
      $scope.selectedEvent.eventOwner = '';
      $scope.selectedEvent.eventStartDate = '';	  
      $scope.selectedEvent.eventEndDate = '';	  
	  
      $scope.selectedEvent.eventDifficulty = '';
	  
    });

  }
  
  $scope.checkAll = function () {
    $scope.selectedAll = false;
    if(!$scope.selectedAll) { 
      $scope.selectedAll = true;
    } else { 
      $scope.selectedAll = false;
    }
    angular.forEach($scope.events, function(event){
      event.selected = $scope.selectedAll;
    });
  }
  $scope.singleEventtSelected = false;
  
  $scope.setSelectedEvent = function (event){
    if($scope.events.filter(x => x.selected).length > 1){
      $scope.selectedEvent = null;
      $scope.singleEventtSelected = false;
	  localStorage.setItem('selectedEventID', 0);
	  
    } else {
      $scope.selectedEvent = angular.copy($scope.events.find(x => x.selected));
      $scope.singleEventtSelected = !!$scope.selectedEvent;
	  localStorage.setItem('selectedEventID', $scope.selectedEvent.id);
	  
    }
  }
  
  $scope.edit = function() {
    if(!!$scope.events.find(x => x.eventName === $scope.selectedEvent.eventName && x.eventDescription === $scope.selectedEvent.eventDescription 
				&& x.eventOwner === $scope.selectedEvent.eventOwner && x.eventStartDate === $scope.selectedEvent.eventStartDate && x.eventEndDate === $scope.selectedEvent.eventEndDate && x.eventDifficulty === $scope.selectedEvent.eventDifficulty)) {
      //alert('already eixsts');
      $scope.errorMessage = true;
      return;
    }
		var StudentJSON = { "eventName": "", "eventDescription": "" , "eventOwner": "", "eventStartDate": "", "eventEndDate": "", "eventDifficulty": ""};	
		var Student_Modify_url = "http://npsevents.pythonanywhere.com/event/"+$scope.selectedEvent.id;

		StudentJSON.eventName = $scope.selectedEvent.eventName;
		StudentJSON.eventDescription = $scope.selectedEvent.eventDescription;
		StudentJSON.eventOwner = $scope.selectedEvent.eventOwner;
		StudentJSON.eventStartDate = $scope.selectedEvent.eventStartDate;
		StudentJSON.eventEndDate = $scope.selectedEvent.eventEndDate;
		
		StudentJSON.eventDifficulty = $scope.selectedEvent.eventDifficulty;
		$http.put(Student_Modify_url,StudentJSON).success(function(response) 
		{
			if(response.err){
			  console.log('Error: ' + response.err);
			  newDataList.push(selected);

			} else {
				console.log('Saved '+response);
				var studentToEdit = $scope.events.find(x => x.id === $scope.selectedEvent.id);
				studentToEdit.eventName = $scope.selectedEvent.eventName;
				studentToEdit.eventDescription = $scope.selectedEvent.eventDescription;
				studentToEdit.eventOwner = $scope.selectedEvent.eventOwner;	
				studentToEdit.eventStartDate = $scope.selectedEvent.eventStartDate;	
				studentToEdit.eventEndDate = $scope.selectedEvent.eventEndDate;	
				
				studentToEdit.eventDifficulty = $scope.selectedEvent.eventDifficulty;			  

			}
	
		});

	  }

}]);